﻿namespace Ecommerce.Infrastructure.Sql.Configurations
{
    //public class ShippingAreaConfiguration : IEntityTypeConfiguration<ShippingArea>
    //{
    //    public void Configure(EntityTypeBuilder<ShippingArea> builder)
    //    {
    //        builder.HasKey(x => x.Id);
    //        //builder.Property(r => r.Id)
    //        //     .ValueGeneratedNever();

    //        builder.Property(prop => prop.AreaName)
    //            .HasMaxLength(256)
    //            .IsRequired();

    //        builder.Property(prop => prop.AreaName)
    //            .HasMaxLength(256)
    //            .IsRequired();

    //        builder.Property(prop => prop.IsActive)
    //            .HasDefaultValue(false);

    //    }
    //}
}
