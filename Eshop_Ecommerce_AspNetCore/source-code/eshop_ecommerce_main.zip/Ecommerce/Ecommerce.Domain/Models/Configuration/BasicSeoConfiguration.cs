﻿namespace Ecommerce.Domain.Models
{
    public class BasicSeoConfiguration
    {
        public string SeoTitle { get; set; }
        public string SeoDescription { get; set; }
        public string SeoKeywords { get; set; }
    }
}
