﻿
namespace Ecommerce.Domain.Models
{
    public class FeatureProductConfiguration
    {
        public int ProductId { get; set; }
        public int Order { get; set; }
    }
}
