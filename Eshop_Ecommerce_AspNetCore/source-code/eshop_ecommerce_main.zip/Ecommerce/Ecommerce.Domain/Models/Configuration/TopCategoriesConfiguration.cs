﻿namespace Ecommerce.Domain.Models
{
    public class TopCategoriesConfiguration
    {
        public int CategoryId { get; set; }
        public string Image { get; set; }
        public int Order { get; set; }
    }

}
