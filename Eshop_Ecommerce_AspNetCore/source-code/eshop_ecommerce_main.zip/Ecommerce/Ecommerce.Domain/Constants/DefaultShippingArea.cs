﻿namespace Ecommerce.Domain.Constants
{
    //public static class DefaultShippingArea
    //{
    //    public static ShippingArea InsideCity() { return new ShippingArea { AreaCode = "IC", AreaName = "Inside City", DeliveryCharge = 0, IsActive = true }; }
    //    public static ShippingArea OutsideCity() { return new ShippingArea { AreaCode = "OC", AreaName = "Outside City", DeliveryCharge = 0, IsActive = true }; }

    //    public static List<ShippingArea> GetDefaultShippingArea()
    //    {
    //        var defaultShippingArea = new List<ShippingArea>();
    //        defaultShippingArea.Add(InsideCity());
    //        defaultShippingArea.Add(OutsideCity());
    //        return defaultShippingArea;
    //    }
    //}
}
