﻿namespace Ecommerce.Domain.Constants
{
    public static class PaymentStatus
    {
        public const string Paid = "Paid";
    }
}
