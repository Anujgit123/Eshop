﻿namespace Ecommerce.Domain.Constants
{
    public static class ProductVarientTheme
    {
        public const string Color = "Color";
        public const string Size = "Size";
        public const string ColorSize = "Color-Size";
    }
}
