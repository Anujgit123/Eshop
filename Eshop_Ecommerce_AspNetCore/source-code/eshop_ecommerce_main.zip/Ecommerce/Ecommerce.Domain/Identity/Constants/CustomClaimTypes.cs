﻿namespace Ecommerce.Domain.Identity.Constants
{
    public class CustomClaimTypes
    {
        public const string Permission = "Permission";
    }
}
