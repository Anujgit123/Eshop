﻿namespace Ecommerce.Domain.Entities
{
    public class ProductImage
    {
        public int ProductId { get; set; }
        public string ImageId { get; set; }
    }
}
