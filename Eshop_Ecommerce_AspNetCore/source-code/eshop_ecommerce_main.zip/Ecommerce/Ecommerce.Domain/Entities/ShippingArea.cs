﻿namespace Ecommerce.Domain.Entities
{
    //public class ShippingArea : BaseEntity
    //{
    //    public int Id { get; set; }
    //    public string AreaCode { get; set; }
    //    public string AreaName { get; set; }
    //    public decimal DeliveryCharge { get; set; }
    //    public bool IsActive { get; set; }
    //    public List<Order> Orders { get; set; }
    //}
}
