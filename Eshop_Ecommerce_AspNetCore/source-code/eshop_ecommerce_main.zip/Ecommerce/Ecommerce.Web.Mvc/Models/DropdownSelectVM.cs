﻿namespace Ecommerce.Web.Mvc.Models
{
    public class DropdownSelectVM
    {
        public dynamic Text { get; set; }
        public dynamic Value { get; set; }
    }
}
