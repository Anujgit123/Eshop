﻿namespace Ecommerce.Application.Dto
{
    public class RoleIdentityDto
    {
        public string RoleId { get; set; }
    }
}
