﻿namespace Ecommerce.Application.Dto
{
    public class ManageRoleDto
    {
        public string Name { get; set; }
        public bool Checked { get; set; }
    }
}
