﻿namespace Ecommerce.Application.Dto
{
    public class SocialProfileDto
    {
        public string Facebook { get; set; }
        public string Youtube { get; set; }
        public string Twitter { get; set; }
        public string Instagram { get; set; }
        public string Linkedin { get; set; }
    }
}
