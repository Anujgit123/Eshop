﻿namespace Ecommerce.Application.Dto
{
    public class BasicSeoConfigurationDto
    {
        public string SeoTitle { get; set; }
        public string SeoDescription { get; set; }
        public string SeoKeywords { get; set; }
    }
}
