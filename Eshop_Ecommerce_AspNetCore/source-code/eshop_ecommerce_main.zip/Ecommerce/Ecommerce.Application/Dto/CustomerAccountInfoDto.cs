﻿namespace Ecommerce.Application.Dto
{
    public class CustomerAccountInfoDto
    {
        public string FullName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
    }
}
