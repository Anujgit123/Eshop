﻿namespace Ecommerce.Application.Dto
{
    public class ProductDetailsFilterResultDto
    {
        public int VarientId { get; set; }
        public string Sku { get; set; }
        public int Quantity { get; set; }
        public string Price { get; set; }
        public string VarientImage { get; set; }
        public string SizeId { get; set; }
        public string ColorId { get; set; }
    }
}
