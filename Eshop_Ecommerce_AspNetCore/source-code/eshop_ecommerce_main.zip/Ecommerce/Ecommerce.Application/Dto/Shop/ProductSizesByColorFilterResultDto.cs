﻿namespace Ecommerce.Application.Dto
{
    public class ProductSizesByColorFilterResultDto
    {
        public string SizeId { get; set; }
        public string Name { get; set; }
    }
}
