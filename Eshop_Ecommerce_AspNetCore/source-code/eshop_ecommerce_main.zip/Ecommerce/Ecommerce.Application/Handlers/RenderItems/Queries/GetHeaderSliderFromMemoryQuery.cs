﻿namespace Ecommerce.Application.Handlers.RenderItems.Queries
{
    //public class GetHeaderSliderFromMemoryQuery : IRequest<List<HeaderSliderDto>>
    //{
    //}
    //public class GetHeaderSliderQueryHandler : IRequestHandler<GetHeaderSliderFromMemoryQuery, List<HeaderSliderDto>>
    //{
    //    private readonly IKeyAccessor _keyAccessor;
    //    public GetHeaderSliderQueryHandler(IKeyAccessor keyAccessor)
    //    {
    //        _keyAccessor = keyAccessor;
    //    }

    //    public async Task<List<HeaderSliderDto>> Handle(GetHeaderSliderFromMemoryQuery request, CancellationToken cancellationToken)
    //    {
    //        List<HeaderSliderDto> getheaderSlider = JsonSerializer.Deserialize<List<HeaderSliderDto>>(_keyAccessor.GetSection("HeaderSlider"));
    //        List<HeaderSliderDto> headerSlider = new List<HeaderSliderDto>();

    //        if (getheaderSlider != null)
    //        {
    //            headerSlider = getheaderSlider;
    //        }

    //        return headerSlider;
    //    }

    //}
}
